#!/usr/bin/env python3

#
# This file is part of LitePCIe.
#
# Copyright (c) 2020 Florent Kermarrec <florent@enjoy-digital.fr>
# SPDX-License-Identifier: BSD-2-Clause

import os
import argparse

from migen import *

from litex.gen import *

from litex_boards.platforms import sqrl_fk33

from litex.soc.cores.clock import USPPLL
from litex.soc.interconnect.csr import *
from litex.soc.integration.soc import *
from litex.soc.integration.builder import *

from litepcie.phy.usppciephy import USPHBMPCIEPHY
from litepcie.core import LitePCIeEndpoint, LitePCIeMSI
from litepcie.frontend.dma import LitePCIeDMA
from litepcie.frontend.wishbone import LitePCIeWishboneBridge
from litepcie.software import generate_litepcie_software

# CRG ----------------------------------------------------------------------------------------------

class _CRG(LiteXModule):
    def __init__(self, platform, sys_clk_freq):
        self.cd_sys = ClockDomain()

        # # #

        # PLL
        self.pll = pll = USPPLL(speedgrade=-2)
        pll.register_clkin(platform.request("clk200"), 200e6)
        pll.create_clkout(self.cd_sys, sys_clk_freq)

# LitePCIeSoC --------------------------------------------------------------------------------------

class LitePCIeSoC(SoCMini):
    configs = {
        # Gen3  data_width, sys_clk_freq
        "gen3:x4" : (128, int(200e6)),
        "gen3:x8" : (256, int(200e6)),
        "gen3:x16": (512, int(200e6)),
    }
    def __init__(self, platform, speed="gen3", nlanes=4):
        data_width, sys_clk_freq = self.configs[speed + f":x{nlanes}"]

        # SoCMini ----------------------------------------------------------------------------------
        SoCMini.__init__(self, platform, sys_clk_freq, ident=f"LitePCIe example design on FK33 ({speed}:x{nlanes})")

        # CRG --------------------------------------------------------------------------------------
        self.crg = _CRG(platform, sys_clk_freq)

        # JTAGBone ---------------------------------------------------------------------------------
        self.add_jtagbone()

        # PCIe -------------------------------------------------------------------------------------
        # PHY
        self.pcie_phy = USPHBMPCIEPHY(platform, platform.request(f"pcie_x{nlanes}"),
            speed      = speed,
            data_width = data_width,
            bar0_size  = 0x20000,
        )
        self.pcie_phy.add_ltssm_tracer()

        # Endpoint
        self.pcie_endpoint = LitePCIeEndpoint(self.pcie_phy,
            endianness           = "little",
            max_pending_requests = 8
        )

        # Wishbone bridge
        self.pcie_bridge = LitePCIeWishboneBridge(self.pcie_endpoint,
            base_address = self.mem_map["csr"])
        self.bus.add_master(master=self.pcie_bridge.wishbone)

        # DMA0
        self.pcie_dma0 = LitePCIeDMA(self.pcie_phy, self.pcie_endpoint,
            with_buffering = True, buffering_depth=1024,
            with_loopback  = True)

        # DMA1
        self.pcie_dma1 = LitePCIeDMA(self.pcie_phy, self.pcie_endpoint,
            with_buffering = True, buffering_depth=1024,
            with_loopback  = True)

        self.add_constant("DMA_CHANNELS", 2)
        self.add_constant("DMA_ADDR_WIDTH", 32)

        # MSI
        self.pcie_msi = LitePCIeMSI()
        self.comb += self.pcie_msi.source.connect(self.pcie_phy.msi)
        self.interrupts = {
            "PCIE_DMA0_WRITER":    self.pcie_dma0.writer.irq,
            "PCIE_DMA0_READER":    self.pcie_dma0.reader.irq,
            "PCIE_DMA1_WRITER":    self.pcie_dma1.writer.irq,
            "PCIE_DMA1_READER":    self.pcie_dma1.reader.irq,
        }
        for i, (k, v) in enumerate(sorted(self.interrupts.items())):
            self.comb += self.pcie_msi.irqs[i].eq(v)
            self.add_constant(k + "_INTERRUPT", i)

# Build --------------------------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="LitePCIe SoC on FK33")
    parser.add_argument("--build",      action="store_true",   help="Build bitstream")
    parser.add_argument("--driver",     action="store_true",   help="Generate LitePCIe driver")
    parser.add_argument("--load",       action="store_true",   help="Load bitstream (to SRAM)")
    parser.add_argument("--speed",      default="gen3",       help="PCIe speed: gen3")
    parser.add_argument("--nlanes",     default=4,            help="PCIe lanes: 4 (default), 8 or 16")
    parser.add_argument("--output-dir", default="build/fk33", help="Build output directory")
    parser.add_argument("--csr-csv",    default="csr.csv",    help="CSR CSV output file")
    args = parser.parse_args()

    platform = sqrl_fk33.Platform()
    soc      = LitePCIeSoC(platform, speed=args.speed, nlanes=int(args.nlanes))
    builder  = Builder(soc, output_dir=args.output_dir, csr_csv=args.csr_csv)
    builder.build(build_name="fk33", run=args.build)

    if args.driver:
        generate_litepcie_software(soc, os.path.join(builder.output_dir, "driver"))

    if args.load:
        prog = soc.platform.create_programmer()
        prog.load_bitstream(os.path.join(builder.gateware_dir, soc.build_name + ".bit"))

if __name__ == "__main__":
    main()
