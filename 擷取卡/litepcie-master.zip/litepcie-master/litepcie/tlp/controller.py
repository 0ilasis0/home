#
# This file is part of LitePCIe.
#
# Copyright (c) 2015-2023 Florent Kermarrec <florent@enjoy-digital.fr>
# SPDX-License-Identifier: BSD-2-Clause

from migen import *

from litex.gen import *

from litepcie.common      import *
from litepcie.core.common import *
from litepcie.tlp.common  import *

# Helpers ------------------------------------------------------------------------------------------

def get_completion_buffer_depth(data_width, max_request_size_bytes=max_request_size, buffered=False):
    # Completion payloads are repacked independently at each TLP boundary. An unaligned request
    # can use one additional stream beat since partial first/last Completion TLPs cannot share one.
    beat_bytes    = data_width//8
    request_beats = (max_request_size_bytes + beat_bytes - 1)//beat_bytes
    # A buffered SyncFIFO already provides the additional beat in its output register.
    return request_beats + (0 if buffered else 1)

# LitePCIe TLP Controller --------------------------------------------------------------------------

class LitePCIeTLPController(LiteXModule):
    """LitePCIe TLP requests/completions controller.

    Arbitrate/throttle TLP requests and reorder/assemble/redirect completions.
    """
    def __init__(self, data_width, address_width, max_pending_requests, cmp_bufs_buffered=True,
        with_configuration=False, cmp_buf_depth=None):
        self.ctrl_rst  = Signal()
        self.master_in  = LitePCIeMasterInternalPort(data_width, address_width, with_configuration=with_configuration)
        self.master_out = LitePCIeMasterInternalPort(data_width, address_width, with_configuration=with_configuration)

        # # #

        req_sink, req_source = self.master_in.sink,    self.master_out.sink
        cmp_sink, cmp_source = self.master_out.source, self.master_in.source

        # Parameters.
        tag_bits = log2_int(max_pending_requests)

        # Tag queue --------------------------------------------------------------------------------
        # The tag queue is filled initially with the tags that will be used to issue read requests
        # to the host. A tag is dequeued when a read requests is issued to the host and queued when
        # a readcomplementation is received from the host.
        self.tag_queue = tag_queue = ResetInserter()(SyncFIFO(
            layout   = [("tag", tag_bits)],
            depth    = max_pending_requests,
            buffered = True,
        ))

        # Requests queue ---------------------------------------------------------------------------
        # Store the read requests tags as emitted to the host, datas will be dequeued in this order
        self.req_queue = req_queue = ResetInserter()(SyncFIFO(
            layout   =  [("tag", tag_bits), ("channel", 8), ("user_id", 8)],
            depth    = max_pending_requests,
            buffered = True,
        ))

        # Requests Management ----------------------------------------------------------------------

        # Connect Data-Path.
        self.comb += req_sink.connect(req_source, omit={"valid", "ready", "tag"})

        # FSM.
        self.req_fsm = req_fsm = ResetInserter()(FSM(reset_state="WAIT-REQ"))
        self.comb += [
            tag_queue.reset.eq(self.ctrl_rst),
            req_queue.reset.eq(self.ctrl_rst),
            req_fsm.reset.eq(self.ctrl_rst),
        ]
        req_fsm.act("WAIT-REQ",
            # Wait for a TLP Request...
            If(req_sink.valid & req_sink.first,
                # TLP Write: We can send the request directly.
                If(req_sink.we,
                   NextState("SEND-WRITE-REQ")
                # TLP Read:  We can send the request when one tag available and space in req_queue.
                ).Elif(tag_queue.source.valid & req_queue.sink.ready,
                   NextState("SEND-READ-REQ")
                )
            )
        )
        req_fsm.act("SEND-WRITE-REQ",
            # Connect Control-Path.
            req_sink.connect(req_source, keep={"valid", "ready"}),
            req_source.tag.eq(32),
            # End Request and return to Wait on last valid cycle.
            If(req_source.valid & req_source.ready & req_source.last,
                NextState("WAIT-REQ")
            )
        )
        self.comb += [
            req_queue.sink.tag.eq(tag_queue.source.tag),
            req_sink.connect(req_queue.sink, keep={"channel", "user_id"}),
        ]
        req_fsm.act("SEND-READ-REQ",
            # Connect Control-Path.
            req_sink.connect(req_source, keep={"valid", "ready"}),
            req_source.tag.eq(tag_queue.source.tag),
            # End Request and return to Wait on last valid cycle.
            If(req_source.valid & req_source.ready & req_source.last,
                # Pop Tag from tag_queue.
                tag_queue.source.ready.eq(1),
                # Push Req to req_queue.
                req_queue.sink.valid.eq(1),
                NextState("WAIT-REQ")
            )
        )

        # Completions Data Buffers (Reordering) ----------------------------------------------------
        #                          ┌───────────────┐
        #   Read Requests'Tags ────►   Req Queue   ├───┐
        #                          └───────────────┘   │
        #                                              │
        #                                              ▼
        #                 ┌─► Demux                   Mux
        #             Tag │   ┌──┐    ┌──────────┐   ┌───┐
        #                 │   │  ├────► Buffer 0 ├───►   │
        #                 │   │  │    └──────────┘   │   │
        #                 │   │  │                   │   │
        #                 │   │  │    ┌──────────┐   │   │
        #        Cmp In ──┴───►  ├────► Buffer . ├───►   ├─────► Cmp Out
        #                     │  │    └──────────┘   │   │
        #                     │  │                   │   │
        #                     │  │    ┌──────────┐   │   │
        #                     │  ├────► Buffer N ├───►   │
        #                     └──┘    └──────────┘   └───┘
        #
        #

        cmp_reorder = stream.Endpoint(completion_layout(data_width))
        cmp_bufs    = []

        # Create Buffers.
        if cmp_buf_depth is None:
            cmp_buf_depth = get_completion_buffer_depth(data_width, buffered=cmp_bufs_buffered)
        for i in range(max_pending_requests):
            cmp_buf       = ResetInserter()(SyncFIFO(completion_layout(data_width), cmp_buf_depth, buffered=cmp_bufs_buffered))
            cmp_bufs.append(cmp_buf)
        self.submodules += cmp_bufs
        self.comb += [cmp_buf.reset.eq(self.ctrl_rst) for cmp_buf in cmp_bufs]

        # Connect Cmp Input to Buffers (based on incoming Tag).
        cases = {i: [cmp_reorder.connect(cmp_bufs[i].sink)] for i in range(len(cmp_bufs))}
        cases["default"] = [cmp_reorder.ready.eq(1)]
        self.comb += Case(cmp_reorder.tag, cases)

        # Connect Buffers to Cmp Output (based on Tag from req_queue).
        self.comb += Case(req_queue.source.tag,
            {i: cmp_bufs[i].source.connect(cmp_source) for i in range(len(cmp_bufs))})
        self.comb += [
            # Pop Req from req_queue when Req is fully received.
            # Retire on a normal end-of-completion OR on an error completion (UR/CA):
            # an error Cpl is zero-length so "end" (length == byte_count) never asserts,
            # which would otherwise leave the request un-retired and leak its tag,
            # deadlocking the DMA reader.
            If(cmp_source.valid & cmp_source.last & (cmp_source.end | cmp_source.err),
                req_queue.source.ready.eq(cmp_source.ready),
            ),
            req_queue.source.connect(cmp_source, keep={"channel", "user_id"}),
        ]

        # Retire Tag once the buffered Completion has been consumed in request order.
        tag_retire = Signal()
        self.comb += tag_retire.eq(
            cmp_source.valid & cmp_source.ready & cmp_source.last &
            (cmp_source.end | cmp_source.err)
        )

        # Completions Management -------------------------------------------------------------------

        fill_tag = Signal(tag_bits)
        self.sync += If(self.ctrl_rst, fill_tag.eq(0))

        # Connect Data-Path.
        self.comb += cmp_sink.connect(cmp_reorder, omit={"valid", "ready"})

        # FSM
        self.cmp_fsm = cmp_fsm = ResetInserter()(FSM(reset_state="FILL-TAG-QUEUE"))
        self.comb += cmp_fsm.reset.eq(self.ctrl_rst)
        cmp_fsm.act("FILL-TAG-QUEUE",
            # Pre-fill Tags.
            tag_queue.sink.valid.eq(1),
            tag_queue.sink.tag.eq(fill_tag),
            NextValue(fill_tag, fill_tag + 1),
            If(fill_tag == (max_pending_requests - 1),
                NextState("WAIT")
            )
        )
        cmp_fsm.act("WAIT",
            tag_queue.sink.valid.eq(tag_retire),
            tag_queue.sink.tag.eq(req_queue.source.tag),
            # Wait for a TLP Completion...
            If(cmp_sink.valid & cmp_sink.first,
                NextState("RUN")
            ).Else(
                cmp_sink.ready.eq(1)
            )
        )
        cmp_fsm.act("RUN",
            tag_queue.sink.valid.eq(tag_retire),
            tag_queue.sink.tag.eq(req_queue.source.tag),
            # Connect Control-Path.
            cmp_sink.connect(cmp_reorder, keep={"valid", "ready"}),
            If(cmp_sink.valid & cmp_sink.ready & cmp_sink.last,
                NextState("WAIT")
            )
        )
