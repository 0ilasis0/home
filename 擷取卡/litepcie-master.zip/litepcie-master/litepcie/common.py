#
# This file is part of LitePCIe.
#
# Copyright (c) 2015-2023 Florent Kermarrec <florent@enjoy-digital.fr>
# SPDX-License-Identifier: BSD-2-Clause

from migen import *

from litex.gen import *

from litex.soc.interconnect import stream
from litex.soc.interconnect.stream import *
from litex.soc.interconnect.packet import *

# Constants/Helpers --------------------------------------------------------------------------------

KB = 1024
MB = 1024*KB
GB = 1024*MB

def get_bar_mask(size):
    mask = 0
    found = 0
    for i in range(32):
        if size%2:
            found = 1
        if found:
            mask |= (1 << i)
        size = size >> 1
    return mask

# Layouts ------------------------------------------------------------------------------------------

def phy_layout(data_width):
    layout = [
        ("dat", data_width),
        ("be",  data_width//8)
    ]
    return EndpointDescription(layout)

def configuration_layout(data_width, address_width=32):
    layout = [
        # Request Parameters.
        ("req_id",          16), # Requester ID.
        ("tc",               3), # Traffic Class.
        ("we",               1), # Configuration type; 0 : Read / 1 : Write.
        ("bus_number",       8), # Configuration Bus number.
        ("device_no",        5), # Configuration Device number.
        ("func",             3), # Configuration Function number.
        ("ext_reg",          3), # Configuration Extended Register.
        ("register_no",      6), # Configuration Register number.
        ("tag",              8), # Configuration tag.

        # Data Stream.
        ("dat", data_width),

        # Internal LitePCIe Routing/Identification.
        ("channel", 8), # Crossbar's channel (Used for internal routing).
    ]
    return EndpointDescription(layout)

def request_layout(data_width, address_width=32, with_configuration=False):
    layout = [
        # Request Parameters.
        ("req_id",          16), # Requester ID.
        ("tc",               3), # Traffic Class.
        ("attr",             2), # Attributes (No Snoop / Relaxed Ordering).
        ("we",               1), # Request type; 0 : Read / 1 : Write.
        ("adr",  address_width), # Request address (In Bytes).
        ("len",             10), # Request length (In Dwords).
        ("first_be",         4), # First Dword Byte Enables.
        ("last_be",          4), # Last Dword Byte Enables.
        ("tag",              8), # Request tag.

        # Data Stream.
        ("dat", data_width),

        # Internal LitePCIe Routing/Identification.
        ("channel", 8), # Crossbar's channel (Used for internal routing).
        ("user_id", 8), # Packet identification (Used for packet delimitation).
    ]

    if with_configuration:
        layout += [
            ("is_cfg",       1), # 0: Memory / 1: Configuration (Type 0).

            # CFG addressing.
            ("bus_number",   8),
            ("device_no",    5),
            ("func",         3),
            ("ext_reg",      3),
            ("register_no",  6),
        ]

    return EndpointDescription(layout)

def completion_layout(data_width, address_width=32):
    layout = [
        # Completion Parameters.
        ("req_id",          16), # Requester ID.
        ("cmp_id",          16), # Completion ID.
        ("tc",               3), # Traffic Class.
        ("attr",             2), # Attributes (No Snoop / Relaxed Ordering).
        ("adr",  address_width), # Completion address (In Bytes).
        ("len",             10), # Completion length (In Dwords).
        ("byte_count",      12), # Remaining Completion Byte Count.
        ("end",              1), # Completion end (Current packet is the last).
        ("err",              1), # Completion error.
        ("tag",              8), # Completion tag.

        # Data Stream.
        ("dat",     data_width),
        ("be",      data_width//8), # Valid payload bytes on the current beat.

        # Internal LitePCIe Routing/Identification.
        ("channel", 8), # Crossbar's channel (Used for internal routing).
        ("user_id", 8)  # Packet identification (Used for packet delimitation).
    ]
    return EndpointDescription(layout)

def ptm_layout(data_width):
    layout = [
        ("request",       1), # Request.
        ("response",      1), # Response.
        ("requester_id", 16), # Requester ID.
        ("length",       10), # Length.
        ("message_code",  8), # Message Code.
        ("master_time",  64), # Master Time.

        # Data Stream.
        ("dat", data_width),

        # Internal LitePCIe Routing/Identification.
        ("channel", 8), # Crossbar's channel (Used for internal routing).
    ]
    return EndpointDescription(layout)


def msi_layout():
    return [("dat", 8)]

def dma_layout(data_width):
    layout = [("data", data_width)]
    return EndpointDescription(layout)
