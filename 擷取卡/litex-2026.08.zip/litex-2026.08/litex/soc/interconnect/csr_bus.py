#
# This file is part of LiteX.
#
# Copyright (c) 2015 Sebastien Bourdeauducq <sb@m-labs.hk>
# Copyright (c) 2015-2023 Florent Kermarrec <florent@enjoy-digital.fr>
# Copyright (c) 2016-2019 Tim 'mithro' Ansell <me@mith.ro>
# SPDX-License-Identifier: BSD-2-Clause

"""
CSR-Bus support for LiteX.

The CSR Bus is a lightweight and low-bandwidth bus design for accessing Configuration and Status
Registers (CSRs).

It takes a minimalist approach, featuring only adr, we, dat_w, and dat_r signals and operate on
sys_clk domain of the SoC, completing writes in a single cycle and reads in two cycles.

                         ┌───────────┐                  Write in 1 cycle:
                         │           │                  - adr/we/dat_w set by bridge.
                         │           ├───► adr
                         |           |                  Read in 2 cycles:
                         │           ├───► re           - adr and re set by bridge.
       Main SoC Bus ◄────►           │                  - User logic can ignore re if there is no reading side effect.
                         |    CSR    ├───► we           - dat_r set returned by user logic.
                         │   Bridge  │
                         │           ├───► dat_w
                         │           │
                         │           ◄──── dat_r
                         └───────────┘

Think of it as LiteX's version of a local bus usually used in FPGA/SoC design to simplify creation
of registers in SoCs.

More information available at: https://github.com/enjoy-digital/litex/wiki/CSR-Bus
"""

from migen import *
from migen.genlib.record import *
from migen.util.misc import xdir

from litex.gen import *
from litex.gen.genlib.misc import chooser

from litex.soc.interconnect import csr
from litex.soc.interconnect.csr import CSRStorage

# CSR Definition -----------------------------------------------------------------------------------

_layout = [
    ("adr",  "address_width", DIR_M_TO_S),
    ("re",                 1, DIR_M_TO_S),
    ("we",                 1, DIR_M_TO_S),
    ("dat_w",   "data_width", DIR_M_TO_S),
    ("dat_r",   "data_width", DIR_S_TO_M)
]

class Interface(Record):
    addressing = "word"
    def __init__(self, data_width=8, address_width=14, alignment=32):
        self.data_width    = data_width
        self.address_width = address_width
        self.alignment     = alignment
        Record.__init__(self, set_layout_parameters(_layout,
            data_width    = data_width,
            address_width = address_width,
        ))
        self.adr.reset_less   = True
        self.dat_w.reset_less = True
        self.dat_r.reset_less = True

    @classmethod
    def like(self, other):
        return Interface(
            data_width    = len(other.dat_w),
            address_width = len(other.adr),
        )

    def write(self, adr, dat):
        yield self.adr.eq(adr)
        yield self.dat_w.eq(dat)
        yield self.we.eq(1)
        yield
        yield self.we.eq(0)

    def read(self, adr):
        yield self.adr.eq(adr)
        yield self.re.eq(1)
        yield
        value = (yield self.dat_r)
        yield self.re.eq(0)
        return value

# CSR Interconnect ---------------------------------------------------------------------------------

class Interconnect(Module):
    def __init__(self, master, slaves):
        self.comb += master.connect(*slaves)


class InterconnectShared(Module):
    def __init__(self, masters, slaves):
        intermediate = Interface.like(masters[0])
        self.comb += [
            intermediate.adr.eq(  Reduce("OR", [masters[i].adr   for i in range(len(masters))])),
            intermediate.re.eq(   Reduce("OR", [masters[i].re    for i in range(len(masters))])),
            intermediate.we.eq(   Reduce("OR", [masters[i].we    for i in range(len(masters))])),
            intermediate.dat_w.eq(Reduce("OR", [masters[i].dat_w for i in range(len(masters))]))
        ]
        for i in range(len(masters)):
            self.comb += masters[i].dat_r.eq(intermediate.dat_r)
        self.comb += intermediate.connect(*slaves)

# CSR SRAM -----------------------------------------------------------------------------------------

class SRAM(Module):
    def __init__(self, mem_or_size, address, read_only=None, init=None, bus=None, paging=0x800):
        if bus is None:
            bus = Interface()
        self.bus = bus
        aligned_paging = paging//4
        data_width = len(self.bus.dat_w)
        if isinstance(mem_or_size, Memory):
            mem = mem_or_size
        else:
            mem = Memory(data_width, mem_or_size//(data_width//8), init=init)
        mem_size = int(mem.width*mem.depth/8)
        csrw_per_memw = (mem.width + data_width - 1)//data_width
        word_bits = log2_int(csrw_per_memw)
        page_bits = log2_int((mem.depth*csrw_per_memw + aligned_paging - 1)//aligned_paging, False)
        if page_bits:
            self._page = CSRStorage(page_bits, name=mem.name_override + "_page", description="SRAM CSR memory page.")
            print("WARNING: SRAM CSR memory will require paged access.")
        else:
            self._page = None
        if read_only is None:
            if hasattr(mem, "bus_read_only"):
                read_only = mem.bus_read_only
            else:
                read_only = False

        # # #

        port = mem.get_port(write_capable=not read_only)
        self.specials += mem, port

        sel = Signal()
        sel_r = Signal()
        self.sync += sel_r.eq(sel)
        self.comb += sel.eq(self.bus.adr[log2_int(aligned_paging):] == address)

        if word_bits:
            word_index    = Signal(word_bits, reset_less=True)
            word_expanded = Signal(csrw_per_memw*data_width)
            self.sync += word_index.eq(self.bus.adr[:word_bits])
            self.comb += [
                word_expanded.eq(port.dat_r),
                If(sel_r,
                    chooser(word_expanded, word_index, self.bus.dat_r, n=csrw_per_memw, reverse=True)
                )
            ]
            if not read_only:
                wregs = []
                for i in range(csrw_per_memw-1):
                    wreg = Signal(data_width, reset_less=True)
                    self.sync += If(sel & self.bus.we & (self.bus.adr[:word_bits] == i), wreg.eq(self.bus.dat_w))
                    wregs.append(wreg)
                memword_chunks = [self.bus.dat_w] + list(reversed(wregs))
                self.comb += [
                    port.we.eq(sel & self.bus.we & (self.bus.adr[:word_bits] == csrw_per_memw - 1)),
                    port.dat_w.eq(Cat(*memword_chunks))
                ]
        else:
            self.comb += If(sel_r, self.bus.dat_r.eq(port.dat_r))
            if not read_only:
                self.comb += [
                    port.we.eq(sel & self.bus.we),
                    port.dat_w.eq(self.bus.dat_w)
                ]

        if self._page is None:
            self.comb += port.adr.eq(self.bus.adr[word_bits:word_bits+len(port.adr)])
        else:
            pv = self._page.storage
            self.comb += port.adr.eq(Cat(self.bus.adr[word_bits:word_bits+len(port.adr)-len(pv)], pv))

    def get_csrs(self):
        if self._page is None:
            return []
        else:
            return [self._page]

# CSR Bank -----------------------------------------------------------------------------------------

class CSRBank(csr.GenericBank):
    def __init__(self, description, address=0, bus=None, paging=0x800, ordering="big"):
        if bus is None:
            bus = Interface()
        self.bus = bus
        aligned_paging = paging//4

        # # #

        csr.GenericBank.__init__(self,
            description = description,
            busword     = len(self.bus.dat_w),
            ordering    = ordering,
        )

        sel = Signal()
        self.comb += sel.eq(self.bus.adr[log2_int(aligned_paging):] == address)

        for i, c in enumerate(self.simple_csrs):
            self.comb += [
                c.wr_data.eq(self.bus.dat_w[:c.size]),
                If(sel & (self.bus.adr[:log2_int(aligned_paging)] == i),
                    c.wr_stb.eq(self.bus.we),
                    c.rd_stb.eq(self.bus.re)
                )
            ]

        brcases = dict((i, self.bus.dat_r.eq(c.rd_data)) for i, c in enumerate(self.simple_csrs))
        self.sync += [
            self.bus.dat_r.eq(0),
            If(sel, Case(self.bus.adr[:log2_int(aligned_paging)], brcases))
        ]


# address_map(name, memory) returns the CSR offset at which to map
# the CSR object (register bank or memory).
# If memory=None, the object is the register bank of object source.name.
# Otherwise, it is a memory object belonging to source.name.
# address_map is called exactly once for each object at each call to
# scan(), so it can have side effects.

class CSRBankArray(Module):
    def __init__(self, source, address_map, *ifargs, paging=0x800, ordering="big", **ifkwargs):
        self.source             = source
        self.address_map        = address_map
        self.paging             = paging
        self.ordering           = ordering
        self.scan(ifargs, ifkwargs)

    def scan(self, ifargs, ifkwargs):

        self.banks     = []
        self.srams     = []
        self.constants = []

        for name, obj in xdir(self.source, True):

            # Collect CSR Registers.
            # ---------------------
            csrs = []
            if hasattr(obj, "get_csrs"): # FIXME: Simplify.
                if "sort" in obj.get_csrs.__code__.co_varnames:
                    csrs = obj.get_csrs(sort=True)
                else:
                    csrs = obj.get_csrs()

            # Collect CSR Memories.
            # ---------------------
            if hasattr(obj, "get_memories"):
                memories = obj.get_memories()
                for memory in memories:
                    if isinstance(memory, tuple):
                        read_only, memory = memory
                    else:
                        read_only = False
                    mapaddr = self.address_map(name, memory)
                    if mapaddr is None:
                        continue
                    sram_bus = Interface(*ifargs, **ifkwargs)
                    mmap = SRAM(memory, mapaddr,
                        read_only = read_only,
                        bus       = sram_bus,
                        paging    = self.paging)
                    self.submodules += mmap
                    csrs += mmap.get_csrs()
                    self.srams.append((name, memory, mapaddr, mmap))

            # Collect CSR Constants.
            # ----------------------
            if hasattr(obj, "get_constants"): # FIXME: Simplify.
                if "sort" in obj.get_constants.__code__.co_varnames:
                    for constant in obj.get_constants(sort=True):
                        self.constants.append((name, constant))
                else:
                    for constant in obj.get_constants():
                        self.constants.append((name, constant))


            # Create CSRBank with CSRs found.
            # -------------------------------
            if csrs:
                mapaddr = self.address_map(name, None)
                if mapaddr is None:
                    continue
                bank_bus = Interface(*ifargs, **ifkwargs)
                rmap = CSRBank(csrs, mapaddr,
                    bus                = bank_bus,
                    paging             = self.paging,
                    ordering           = self.ordering)
                self.submodules += rmap
                self.banks.append((name, csrs, mapaddr, rmap))

    def get_rmaps(self):
        return [rmap for name, csrs, mapaddr, rmap in self.banks]

    def get_mmaps(self):
        return [mmap for name, memory, mapaddr, mmap in self.srams]

    def get_buses(self):
        return [i.bus for i in self.get_rmaps() + self.get_mmaps()]
