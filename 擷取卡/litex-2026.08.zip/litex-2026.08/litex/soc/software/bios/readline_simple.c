// This file is Copyright (c) 2013-2014 Sebastien Bourdeauducq <sb@m-labs.hk>
// This file is Copyright (c) 2014-2019 Florent Kermarrec <florent@enjoy-digital.fr>

// SPDX-License-Identifier: BSD-Source-Code

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <libbase/uart.h>

#include "readline.h"

static void (*idle_hook_ptr)(void) = NULL;

void set_idle_hook(void (*fptr)(void))
{
	idle_hook_ptr = fptr;
}

int readline(char *s, int size)
{
	static char skip = 0;
	char c[2];
	int ptr;
	int escape = 0;

	if (size <= 0)
		return -1;

	c[1] = 0;
	ptr = 0;
	while(1) {
		if (idle_hook_ptr != NULL) {
			while (!uart_read_nonblock()) {
				idle_hook_ptr();
			}
		}

		c[0] = getchar();
		if (c[0] == 0x03) {
			s[0] = 0;
			skip = 0;
			return -1;
		}
		if (c[0] == skip)
			continue;
		skip = 0;
		/* Ignore complete CSI/SS3 key sequences, including their printable
		   suffixes. Consume incrementally so a lone ESC cannot block input. */
		if (c[0] == 0x1b) {
			escape = 1;
			continue;
		}
		if (escape && c[0] != '\r' && c[0] != '\n') {
			if (escape == 1)
				escape = (c[0] == '[' || c[0] == 'O') ? 2 : 0;
			else if (c[0] >= 0x40 && c[0] <= 0x7e)
				escape = 0;
			continue;
		}
		switch(c[0]) {
		case 0x7f:
		case 0x08:
			if(ptr > 0) {
				ptr--;
				fputs("\x08 \x08", stdout);
			}
			break;
		case 0x07:
			break;
		case '\r':
			skip = '\n';
			s[ptr] = 0x00;
			fputs("\n", stdout);
			return 0;
		case '\n':
			skip = '\r';
			s[ptr] = 0x00;
			fputs("\n", stdout);
			return 0;
		default:
			/* Only store printable characters: escape sequences (arrow/
			   function keys) and control characters would end up as garbage
			   in the command buffer. */
			if (!isascii(c[0]) || !isprint(c[0]))
				break;
			if (ptr < (size - 1)) {
				fputs(c, stdout);
				s[ptr] = c[0];
				ptr++;
			} else {
				putchar('\a');
			}
			break;
		}
	}

	return 0;
}
