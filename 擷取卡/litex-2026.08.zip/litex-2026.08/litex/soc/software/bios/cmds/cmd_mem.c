// SPDX-License-Identifier: BSD-Source-Code

#include <stdio.h>
#include <stdlib.h>
#include <libbase/parse.h>
#include <stdbool.h>
#include <stdint.h>
#include <libbase/memtest.h>

#include <generated/csr.h>
#include <generated/mem.h>

#include "../command.h"
#include "../helpers.h"

/**
 * Command "mem_list"
 *
 * Memory list
 *
 */
static void mem_list_handler(int nb_params, char **params)
{
	printf("Available memory regions:\n");
#ifdef MEM_REGIONS_DETAILS
	puts(MEM_REGIONS_DETAILS);
#else
	puts(MEM_REGIONS);
#endif
}

define_command_args(mem_list, mem_list_handler, "List available memory regions",
	"mem_list", 0, 0, MEM_CMDS);

/**
 * Command "mem_read"
 *
 * Memory read
 *
 */
static void mem_read_handler(int nb_params, char **params)
{
	unsigned long address;
	unsigned int *addr;
	unsigned int length;

	if (!parse_ulong(params[0], &address)) {
		printf("Error: invalid address\n");
		return;
	}
	addr = (unsigned int *)address;
	if (nb_params == 1) {
		length = 4;
	} else {
		if (!parse_uint(params[1], &length)) {
			printf("Error: invalid length\n");
			return;
		}
	}

	dump_bytes(addr, length, (unsigned long)addr);
}

define_command_args(mem_read, mem_read_handler, "Read address space",
	"mem_read <address> [length]", 1, 2, MEM_CMDS);

/**
 * Command "mem_write"
 *
 * Memory write
 *
 */
static void mem_write_handler(int nb_params, char **params)
{
	unsigned long address;
	void *addr;
	unsigned int value;
	unsigned int count;
	unsigned int size;
	unsigned int i;


	size = 4;
	if (!parse_ulong(params[0], &address)) {
		printf("Error: invalid address\n");
		return;
	}
	addr = (void *)address;

	if (!parse_uint(params[1], &value)) {
		printf("Error: invalid value\n");
		return;
	}

	if (nb_params == 2) {
		count = 1;
	} else {
		if (!parse_uint(params[2], &count)) {
			printf("Error: invalid count\n");
			return;
		}
	}

	if (nb_params == 4) {
		if (!parse_uint(params[3], &size)) {
			printf("Error: invalid size\n");
			return;
		}
	}

	if ((size != 1) && (size != 2) && (size != 4)) {
		printf("Error: invalid size (1, 2 or 4)\n");
		return;
	}

	for (i = 0; i < count; i++) {
		switch (size) {
		case 1:
			*(uint8_t *)addr = value;
			addr += 1;
			break;
		case 2:
			*(uint16_t *)addr = value;
			addr += 2;
			break;
		case 4:
			*(uint32_t *)addr = value;
			addr += 4;
			break;
		}
	}
}

define_command_args(mem_write, mem_write_handler, "Write address space",
	"mem_write <address> <value> [count] [size]", 2, 4, MEM_CMDS);

/**
 * Command "mem_copy"
 *
 * Memory copy
 *
 */
static void mem_copy_handler(int nb_params, char **params)
{
	unsigned long address;
	unsigned int *dstaddr;
	unsigned int *srcaddr;
	unsigned int count;
	unsigned int i;


	if (!parse_ulong(params[0], &address)) {
		printf("Error: invalid destination address\n");
		return;
	}
	dstaddr = (unsigned int *)address;

	if (!parse_ulong(params[1], &address)) {
		printf("Error: invalid source address\n");
		return;
	}
	srcaddr = (unsigned int *)address;

	if (nb_params == 2) {
		count = 1;
	} else {
		if (!parse_uint(params[2], &count)) {
			printf("Error: invalid count\n");
			return;
		}
	}

	for (i = 0; i < count; i++)
		*dstaddr++ = *srcaddr++;
}

define_command_args(mem_copy, mem_copy_handler, "Copy address space",
	"mem_copy <dst> <src> [count (32-bit words)]", 2, 3, MEM_CMDS);

/**
 * Command "mem_test"
 *
 * Memory Test
 *
 */
static void mem_test_handler(int nb_params, char **params)
{
	unsigned long address;
	unsigned int *addr;
	/* Default to the same bounded size as the boot-time memtest: testing
	   "everything" from addr would write over the BIOS data/stack. */
	unsigned long maxsize = MEMTEST_DATA_SIZE;


	if (!parse_ulong(params[0], &address)) {
		printf("Error: invalid address\n");
		return;
	}
	addr = (unsigned int *)address;

	if (nb_params >= 2) {
		if (!parse_ulong(params[1], &maxsize)) {
			printf("Error: invalid size\n");
			return;
		}

	}

	memtest(addr, maxsize);
}
define_command_args(mem_test, mem_test_handler, "Test memory access",
	"mem_test <addr> [maxsize]", 1, 2, MEM_CMDS);

/**
 * Command "mem_speed"
 *
 * Memory Speed
 *
 */
static void mem_speed_handler(int nb_params, char **params)
{
	unsigned long address;
	unsigned int *addr;
	unsigned long size;
	bool read_only = false;
	bool random = false;


	if (!parse_ulong(params[0], &address)) {
		printf("Error: invalid address\n");
		return;
	}
	addr = (unsigned int *)address;

	if (!parse_ulong(params[1], &size)) {
		printf("Error: invalid size\n");
		return;
	}

	if (nb_params >= 3) {
		if (!parse_ulong(params[2], &address)) {
			printf("Error: invalid readonly value\n");
			return;
		}
		read_only = (bool)address;
	}

	if (nb_params >= 4) {
		if (!parse_ulong(params[3], &address)) {
			printf("Error: invalid random value\n");
			return;
		}
		random = (bool)address;
	}

	memspeed(addr, size, read_only, random);
}
define_command_args(mem_speed, mem_speed_handler, "Test memory speed",
	"mem_speed <addr> <size> [readonly] [random]", 2, 4, MEM_CMDS);

/**
 * Command "mem_cmp"
 *
 * Memory Compare
 *
 */
static void mem_cmp_handler(int nb_params, char **params)
{
	unsigned long address;
	unsigned int *addr1;
	unsigned int *addr2;
	unsigned int count;
	unsigned int i;
	bool same = true;

	if (!parse_ulong(params[0], &address)) {
		printf("Error: invalid addr1\n");
		return;
	}
	addr1 = (unsigned int *)address;

	if (!parse_ulong(params[1], &address)) {
		printf("Error: invalid addr2\n");
		return;
	}
	addr2 = (unsigned int *)address;

	if (!parse_uint(params[2], &count)) {
		printf("Error: invalid count\n");
		return;
	}

	for (i = 0; i < count; i++) {
		if (*addr1++ != *addr2++) {
			printf("Different memory content:\naddr1: 0x%08lx, content: 0x%08x\naddr2: 0x%08lx, content: 0x%08x\n",
				(long unsigned int)(addr1 - 1), *(addr1 - 1),
				(long unsigned int)(addr2 - 1), *(addr2 - 1));
			same = false;
		}
	}

	if (same)
		printf("mem_cmp finished, same content.\n");
	else
		printf("mem_cmp finished, different content.\n");
}
define_command_args(mem_cmp, mem_cmp_handler, "Compare memory content",
	"mem_cmp <addr1> <addr2> <count (32-bit words)>", 3, 3, MEM_CMDS);
